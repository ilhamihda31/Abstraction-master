﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.Interface
{
   public class ovipar : IReproduksi
    {
        public void berkembangBiak()
        {
            Console.WriteLine("Ovipar adalah cara berkembang biakkan hewan dengan cara bertelur");
        }
    }
}
