﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.Interface
{
    public interface IReproduksi
    {
      void berkembangBiak();
    }
}
