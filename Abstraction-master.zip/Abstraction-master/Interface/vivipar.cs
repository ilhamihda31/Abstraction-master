﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.Interface
{
    public class vivipar : IReproduksi
    {
        public void berkembangBiak()
        {
            Console.WriteLine("Vivipar adalah cara perkembangbiakan hewan dengan cara beranak atau melahirkan.");
        }
    }
}
