﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.abtractionClass
{
    public class herbivora : hewan 
    {
        public override void jenisMakanan()
        {
            Console.WriteLine("hewan herbivora adalah hewan pemakan tumbuhan");
        }
    }
}
