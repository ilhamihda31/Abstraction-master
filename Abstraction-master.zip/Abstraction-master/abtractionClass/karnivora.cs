﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.abtractionClass
{
  public class karnivora : hewan 
    {
        public override void jenisMakanan()
        {
            Console.WriteLine("hewan karnivora adalah hewan pemakan daging");
        }
    }
}
