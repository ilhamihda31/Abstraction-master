﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Abtraction.abtractionClass
{
    public class omnivora : hewan
    {
        public override void jenisMakanan()
        {
            Console.WriteLine("hewan omnivora adalah hewan pemakan segala");
        }
    }
}
